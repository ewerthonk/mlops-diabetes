# THIS FILE IS GENERATED DURING THE SCIPY BUILD
# See tools/version_utils.py for details

short_version = '1.9.3'
version = '1.9.3'
full_version = '1.9.3'
git_revision = 'de80faf'
commit_count = '2429'
release = True

if not release:
    version = full_version
